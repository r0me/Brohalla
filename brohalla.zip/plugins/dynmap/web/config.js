var config = {
        tileUrl:     'tiles/',
        updateUrl:   'up/',                             // For Apache and lighttpd
//      updateUrl:   'up.php?path=',                    // For Apache and lighttpd without ability to natively proxy
//      updateUrl:   'up.aspx?path=',                   // For IIS
		tileWidth: 128,
		tileHeight: 128
};