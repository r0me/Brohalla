CraftScripts are script files for WorldEdit that let you write world
editing scripts easily.

Example usage:
/cs maze.js lightstone 10 10